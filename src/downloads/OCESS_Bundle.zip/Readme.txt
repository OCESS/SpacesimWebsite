This software bundle is Copyright Dr. Magwood. By downloading it, you agree
not to use it for commercial gain, and only in the pursuit of scientific knowledge
or fun.

This software bundle was developed for the Ottawa-Carleton Educational Space
Simulation program located in the Ottawa region.
www.spacesim.org

---The Programs---

EECOM: The Old Environmental Monitoring System. This does not include the
new door system.

EECOM_MC: This program mirrors all data on the EECOM program and allows Mission
Control to monitor and alter the habitat environment.

EECOM_SM: 
	If it is past December: DELETE THIS NOW!!! IT DOES NOT EXIST!
	If it is not past December: This program allows the simulators to
modify the habitat environment.
	
Orb Calc: The Orbit Calculating software makes it easy to figure out how long
to burn the engines for. This program is run in MC.

ORBIT5O: The Piloting Utility used aboard the Habitat.

ORBIT5OF: Unimportant/Unknown

ORBIT5OM: Telemetry Monitoring Program for Mission Control.

ORBIT5OS:
	If it is past December: DELETE THIS NOW! IT DOES NOT EXIST!!!
	If is is not past December: This program allows the Simulators to
modify the functionality of AYSE and Habitat Systems.

ORBIT5OT: Telemetry and Systems Monitoring Utility for Mission Control.

Transorb: Calculates Orbit Transfers.


If you downloaded this from somewhere other than www.spacesim.org, Please
inform the OCESS by emailing Commanders@spacesim.org. Thank you.